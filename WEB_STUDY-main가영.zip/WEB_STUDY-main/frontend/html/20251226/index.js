// server.mjs
import { createServer } from 'node:http';
import/*불러올거다*/ {controller}/*이것을*/ from'./main.js'/*여기에서*/;

const server = createServer((req, res) => {
  res.writeHead(200, { 
    'Content-Type': 'text/html; charset=utf-8' 
  });
   
  const html = controller(req); /*html 변수 선언 후
  함수를 호출한다 그 값 안에는 요청을 넣는다.*/
  res.end(html); /*html이라는 값으로 응답한다.*/
});

// starts a simple http server locally on port 3000
server.listen(3000, '127.0.0.1', () => {
  console.log('Listening on 127.0.0.1:3000');
});

// run with `node server.mjs`
