
function text(){
    let html="";

    html += "<h1>html 입니다.</h1>";
    html += "<p>node..</p>";


    return html;
}

export/*내보낼거다*/ function controller/*이런 함수가 발동*/(req/*요청을 받으면*/) {
    let html = "";
    let url = req.url;
    const index = req.url.lastIndexOf("?");
    if(index > 0)  url = req.url.substring(0, index); //예외처리
    if(url === "/a"){
        const parameters = new URL(req.url, `http://${req.headers.host}`);
        for (const [key, value] of parameters.searchParams){
            console.log(`${key} : ${value}`);
            html += `<h2>${value}</h2>`;
        }

    //html = "<h2>a주소 화면</h2>";
    } else if(url === "/b"){
      html = "<h2>B 주소 화면 입니다.</h2>";}
      else{
      html = text();
  }
    return html;
}