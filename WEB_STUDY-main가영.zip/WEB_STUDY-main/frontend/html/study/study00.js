//인덱스 도출

let a = "○";
let b = "●";
let 값 = "";

for(let cul = 0 ; cul < 5 ; cul++){
    for(let low = 0; low < 5 ; low++){
        if((cul+low)%2 === 0){
            console.log(값+a)
        }
        else {console.log(값+b)}
    }
    console.log(값)
}


