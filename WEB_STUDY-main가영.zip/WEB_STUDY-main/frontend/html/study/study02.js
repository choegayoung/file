for(let i = 1 ; i <=10 ; i++ ){
    if (i%2 !==0)
        console.log(i)
}

for (let i = 1 ; i <=20 ; i++){
    if (i%3 !== 0)
        console.log(i)
}

let a = "javascript";

for (let i = 0 ; i < 10; i++){
    if(a!=="a"){
        console.log([i])
    }
}