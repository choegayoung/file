const start = 1;
const end1 = 10;
const end2 = 20;
const str ="javascript";
const keyword = "a";

for (let i = start; i <= end1; i++){
     if (i%2 === 0) continue;
        
        console.log(i)
}

for (let i = start; i <=end2; i++){
    if (i%3 === 0) continue;
        console.log(i)
}

for (const s of str){
    if (s === keyword) continue;
    {console.log(s)} 
}