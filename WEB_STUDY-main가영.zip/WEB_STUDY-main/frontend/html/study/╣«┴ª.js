const a = [
  ['A', 'B', 'C'],
  ['D', 'E', 'F'],
  ['G', 'H', 'I']
];



let 문자 = 'F';
let 답 = '';

for (let i = 0; i < a.length; i++) {
  for (let j = 0; j < a[i].length; j++) {
    if (a[i][j] === 문자) {
      답 = [i, j];
    }
  }
}

console.log(`찾는 문자 : ${문자}, 인덱스 값 : ${답}`);