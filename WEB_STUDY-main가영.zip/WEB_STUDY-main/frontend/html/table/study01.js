
function load(){

var page = ""

for(let i = 0 ; i <25 ; i++){

    let css = "1";
    if(i%2===0) css = "2"
    if(i===6) css = "3"
    page += `<div class="bg${css}"></div>`;
}
s = true;
document.getElementsByTagName("section")[0]. innerHTML = page;
}

function loads(){

var page = ""

for(let i = 0 ; i <25 ; i++){
    if(i%2===0){page +='<div class="bg2"></div>';}
    if(i===6){page +='<div class="bg1"></div>';}
    else{ page +='<div class="bg1"></div>';}
    
s = true;
}
document.getElementsByTagName("section")[0]. innerHTML = page;
}

function clean(){
    s = false;
    document.getElementsByTagName("section")[0]. innerHTML = " ";
}

var s = false;

function btn(){
    if(!s){
        load()
    }
    else{
        clean()
    }
}