
$(document).ready(() => {
    
    function view1() {
        var html = "";
    for(let i = 0 ; i <25 ; i++){
    let css = "1";
    if(i%2===0) css = "2"
    if(i===6) css = "3"
    html += `<div class="bg${css}"></div>`;
    }


   $("section").html(html);
   state = true; /*화면이 켜진 상태는 true로 지정*/
}
  var state = false; /*일단 스위치 기본값은 화면이 꺼져있는걸로 설정*/
 $("button"/*페이지 안에 있는 모든 <button> 태그를 부른다 "버튼들아 여기좀봐!"*/)
   .click/*클릭하면 이벤트가 생기는 함수*/(function(e){ /*클릭하면 이런 일이 생긴다*/
    
    const index = $("button").index(e.target);
    if(index===0) {
        view1();
    } else if(index === 1){
        $("section").empty();
        state = false;
    } else if(index === 2){
        if(!state) view1();
        else{
            $("section").empty();
            state = false;
        }
    }
});

});

/*
$(document).ready(() => { ... }) 
-> "페이지가 다 만들어지면 이 안에 코드를 실행해"
 function view1() {              
 -> 함수(묶음)선언."이런 일을 하는 기능을 만들게"
 var html =                      
 ->"div들을 담을 상자를 준비했어"
 $("section").html(html);        
 ->"이제 화면에 div들을 그려!"
 $("button").click(function(e){  
 ->"버튼 누르면 짜잔 할 준비"
 const index = $("button").index(e.target);
 ->"지금 누른 버튼이 몇 번째 버튼이야?"
 if(index===0) {
    view1();   } 
 ->"첫 번째 버튼이면 짜잔 해"
 */